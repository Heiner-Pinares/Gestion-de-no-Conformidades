# Portal Claro — Gestión de No Conformidades

Primera versión funcional local con Django 5.2 LTS, Python 3.12 y PostgreSQL. Conserva el CSS y los SVG del prototipo v8. La autenticación, autorización, persistencia, workflow y cálculos se ejecutan en Python. No utiliza JavaScript propio ni localStorage para negocio.

## Entrega Windows + Oracle 19c

La entrega para Windows usa `requirements-oracle.txt`, `.env.oracle.example` y `run.py`. El esquema se instala una sola vez con `docs/oracle_usrfact/INSTALAR_USRFACT_TODO_EN_UNO.sql`; después, la aplicación se conecta con `USRFACSOP` y rechaza cuentas con privilegios DDL. `python run.py check` valida la conexión y `python run.py start` ejecuta el portal. Consulte [Despliegue Windows con Oracle](docs/DESPLIEGUE_WINDOWS_ORACLE.md) antes de copiar el sistema al servidor.

## Estructura actual: 24 tablas físicas y ninguna vista

PostgreSQL contiene exactamente **24 tablas físicas** y ninguna vista. Los catálogos, procesos, matrices, ciclos, evaluaciones, comunicaciones, evidencias, historial y notificaciones tienen tablas explícitas. `registro_general` es la tabla principal de hallazgos; `archivo_evidencia` guarda los bytes y el SHA-256 de cada documento. `django_session` y `django_migrations` son las dos tablas técnicas.

El menú **Registro general** abre `/registro-general/` con las 34 columnas solicitadas, filtros y exportación CSV. La tabla física `registro_general` conserva cada hallazgo y la fotografía de los rangos seleccionados; el backend combina sus actividades, ciclos y evaluaciones al mostrar o exportar el informe, sin duplicar datos ni crear una vista SQL.

Consulta [Estructura simplificada](docs/ESTRUCTURA_SIMPLIFICADA.md) para el mapa actual y la forma de comprobarlo. Pasan 64 pruebas funcionales sobre PostgreSQL.

## Abrir la instalación preparada en este equipo

La base `gestion_no_conformidades` está en el PostgreSQL existente de `localhost:5432`, junto a `compromisos_db`. La conexión del portal usa su propio rol `portal_nc`, configurado en `.env`.

En Terminal:

```sh
cd "/Users/heinerpinares/Documents/Gestion de no Conformidades/Automatizacion/portal_nc"
.venv/bin/python manage.py runserver 127.0.0.1:8000
```

Abre http://127.0.0.1:8000/ . Mantén la Terminal abierta; Ctrl+C detiene la web. PostgreSQL debe estar encendido. No ejecutes `scripts/local_postgres.py start` para esta instalación: era la instancia anterior del puerto 55432.

Usuarios existentes: `usuario.demo`, `validador.demo` y `admin.demo`, con las contraseñas que configuraste. No necesitas ejecutar `seed_demo_data` al iniciar: ese comando vuelve a asignar las contraseñas demo. Para cambiar una sola: `.venv/bin/python manage.py changepassword usuario.demo`.

En pgAdmin, actualiza Databases del servidor PostgreSQL 18 y abre `gestion_no_conformidades → Schemas → public → Tables`. Para consultar una tabla, usa View/Edit Data → All Rows.

La migración productiva separa el esquema compacto y conserva los identificadores históricos hasta completar 24 tablas. Roles, validadores, sesiones y archivos permanecen dentro de PostgreSQL.

## Instalación en otro equipo

Requisitos: Python 3.12, PostgreSQL 14 o superior, pip y capacidad de crear una base. pgAdmin 4 es opcional para administración; la aplicación no depende de él.

```sh
python3.12 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Configura en `.env`: DB_NAME, DB_USER, DB_HOST, DB_PORT, DEBUG y ALLOWED_HOSTS. Guarda la contraseña en `secrets/postgres_password.txt` y una clave aleatoria en `secrets/django_secret_key.txt`, tal como indica `.env.example`. `.env` y `secrets` están excluidos de Git.

Crea una base vacía y un usuario propio desde pgAdmin o mediante `createuser --pwprompt portal_nc` y `createdb --owner=portal_nc gestion_no_conformidades` con una cuenta PostgreSQL autorizada. Si usas el script aislado, ejecútalo antes de copiar `.env.example`: crea automáticamente `.env` con valores privados y configura su propia instancia. `PG_BIN` permite indicar la carpeta bin de PostgreSQL; `LOCAL_PG_PORT` permite otro puerto local.

```sh
python manage.py migrate
python manage.py seed_initial_data
python manage.py check
python manage.py runserver
```

Las migraciones están incluidas. No se recrean tablas al arrancar. `makemigrations` se usa únicamente al cambiar modelos. No hay una alternativa SQLite que oculte diferencias de concurrencia.

Para desarrollo, `DEBUG=True` y `ENABLE_DEMO_DATA=True` permiten `python manage.py seed_demo_data`. `--noinput` crea cuentas nuevas con contraseña inutilizable salvo que se suministre DEMO_PASSWORD como variable de entorno del proceso. No persistas esa contraseña en archivos. Los casos demo se distinguen por proceso y descripción. La semilla de maestros no crea cuentas ni casos, y ninguna semilla sobrescribe la matriz que ya hayas configurado.

## Roles y acceso

### Ingreso con cuenta corporativa Microsoft

El login permite continuar con Microsoft Entra ID mediante OAuth 2.0 y el flujo de código de autorización con PKCE. En cada ingreso se sincronizan desde Microsoft Graph el nombre, apellidos, correo, puesto y área/departamento. El encabezado muestra el puesto y el área cuando están disponibles. Los tokens de Microsoft no se guardan en la base ni en la sesión; el portal conserva únicamente el identificador corporativo y los datos de perfil.

Para habilitarlo, registra el portal como una aplicación web en Microsoft Entra ID y configura exactamente esta URI de redirección para desarrollo:

```text
http://localhost:8000/cuentas/microsoft/callback/
```

Agrega el permiso delegado de Microsoft Graph `User.Read`, crea un secreto de cliente y crea un archivo local `.env.local` con:

```env
MICROSOFT_SSO_ENABLED=True
MICROSOFT_TENANT_ID=<Id. del directorio (inquilino)>
MICROSOFT_CLIENT_ID=<Id. de la aplicación (cliente)>
MICROSOFT_CLIENT_SECRET_FILE=secrets/microsoft_client_secret.txt
MICROSOFT_REDIRECT_URI=http://localhost:8000/cuentas/microsoft/callback/
```

La autoridad usa el tenant corporativo indicado, por lo que no acepta cuentas personales ni otros directorios. La primera entrada crea un usuario con rol `USUARIO`; un administrador puede añadir roles funcionales desde **Usuarios y roles**. Si ya hay una cuenta local con el mismo correo, se vincula y conserva su contraseña local. En producción registra la URL HTTPS definitiva y cambia `MICROSOFT_REDIRECT_URI` por esa dirección exacta.

| Perfil | Función | Alcance |
|---|---|---|
| Usuario | Crear, corregir, enviar y participar | Casos reportados, asignados o donde tenga una acción; edición según etapa y responsabilidad |
| Calidad | Acompañar el tratamiento, evaluar eficacia y cerrar | Solo procesos asignados; no aprueba la identificación inicial |
| Administrador | Usuarios, roles, catálogos, procesos, reportes y auditoría | Configura la plataforma; no valida hallazgos |

Un usuario puede tener varios roles. El menú combina sus permisos. El administrador asigna validadores desde Catálogos → Procesos. La administración funcional se realiza desde las pantallas propias del portal.

## Flujo disponible

Borrador → Continuar → Análisis de causa raíz. No existe una aprobación administrativa intermedia: toda NC abre directamente el checklist 6M del paso 2.

Toda NC completa primero el análisis 6M. Después, una NC no crítica registra su acción inmediata y comunicación; una NC crítica habilita además las acciones correctivas. Si además es tecnológica, exige referencia manual PBI. La implementación requiere completar las acciones antes de verificar. Eficaz habilita cierre explícito; No eficaz crea otro ciclo conservando análisis, acciones y evaluación anteriores. La reapertura manual de un cerrado también deja motivo y trazabilidad.

Se conservan los trece estados aprobados. Las transiciones se controlan en `apps/hallazgos/services/workflow.py`, con transacciones y bloqueos por caso. La edición de identificación usa versión para detectar cambios concurrentes. Las acciones tienen código SAC-A01, responsables propios, fechas iniciales inmutables, seguimientos y hasta tres reprogramaciones históricas.

## Datos, archivos y seguridad

- Correlativo por tipo/año de inicio, configurable con SAC_SEQUENCE_SCOPE=TYPE o YEAR. Cambiar el modo con códigos existentes requiere migración controlada; se bloquea el cambio silencioso.
- Impacto = máximo de Clientes/Tiempo/Soles. Prioridad consultada en matriz configurable; una combinación ausente detiene el cálculo con mensaje y log.
- Prioridad operativa y NC crítica son conceptos separados. La matriz inicial es DEMO; no están definidos los umbrales oficiales de clientes, tiempo o soles.
- Custom User desde la primera migración. Contraseñas con hash Django; CSRF, escape de templates, sesiones HTTPOnly y cierre por POST.
- Evidencias PDF, Office, PNG y JPEG hasta 10 MB. Extensión y contenido comprobados, binario y SHA-256 guardados en `archivo_evidencia`, y descargas autorizadas y forzadas como adjunto. Los archivos nuevos no dependen de `MEDIA_ROOT`. El reconocimiento de PDF por estructura básica no sustituye un antivirus empresarial.
- Los catálogos se desactivan y las relaciones históricas usan PROTECT. No hay borrado de hallazgos, acciones, evaluaciones ni historial desde la interfaz.
- La auditoría funcional se diferencia de los logs técnicos. Los cambios administrativos conservan valores anteriores/nuevos. CSV protege celdas susceptibles de interpretarse como fórmulas.

## Notificaciones e indicadores

Los cambios del proceso generan avisos internos. No se envían correos ni mensajes externos. Para vencimientos ejecuta explícitamente:

```sh
python manage.py notificar_vencimientos --dias 3
```

Es idempotente por día y acción. No se ha instalado una tarea programada. La ventana de tres días es un parámetro del comando, no una política oficial de Claro.

Un caso vencido tiene fecha de solución anterior a hoy y no está cerrado/cancelado. La eficacia reportada es evaluaciones eficaces / total de evaluaciones, considerando todos los ciclos. Son definiciones documentadas para revisión del negocio; el avance de una acción y su eficacia son distintos.

## Estructura y modelos

- `config/`: configuración y URLs; WSGI/ASGI.
- `apps/accounts/`: Usuario, permisos funcionales, login y grupos.
- `apps/catalogos/`: tipos, fuentes, procesos, subprocesos, impacto, urgencia, prioridad, matriz, estados, categorías/preguntas y auditoría administrativa.
- `apps/hallazgos/`: Hallazgo, correlativo, ciclos, análisis, respuestas, controles, acciones, reprogramaciones, seguimientos, PBI, comunicación, evaluación, cierre, evidencias, historial y notificaciones.
- `services/`: casos de uso con validación/permiso/transacción; `selectors.py`: consultas de alcance; `forms.py`: entrada; `views.py`: adaptación HTTP.
- `templates/`, `static/`: presentación derivada del HTML. SVG originales en includes y CSS original en portal-v8.css.
- `references/`: HTML original intacto.
- `docs/`: auditoría del proceso, supuestos, arquitectura, workflow, trazabilidad y resultado de fases.
- `.runtime/`, `.env`, `media/`, `.venv/`: recursos locales privados, excluidos de Git.

## Pruebas y mantenimiento

```sh
python manage.py check
python manage.py makemigrations --check --dry-run
python manage.py test apps.hallazgos.tests --noinput
```

La suite utiliza PostgreSQL real y crea/destruye su base de pruebas. La cuenta usada para pruebas necesita CREATEDB; usa una cuenta dedicada fuera de producción. Cubre recorrido crítico/no crítico, avance directo sin aprobación administrativa, controles 6M, PBI, reapertura, cierre, permisos, URLs, CSRF, XSS, evidencias, semillas, límites de reprogramación, atomicidad y concurrencia del SAC.

## Pendientes para adopción productiva

Revisar `docs/ASSUMPTIONS.md`. Faltan DOC-CAT-001 y la definición oficial de comunicación; aprobar matriz, alcance de roles, correlativo, NA, escalamiento de no críticas tras no eficacia y cancelación de acciones. El sistema no cambia automáticamente la criticidad en una reapertura.

La integración de Microsoft Entra ID está implementada, pero requiere registrar la aplicación y cargar las credenciales del tenant de la organización. LDAP, Remedy/Helix, correo, antivirus de archivos, límites de intentos del login local, backup/restauración y despliegue HTTPS requieren diseño/configuración operacional. El cambio a producción requiere DEBUG=False, dominio autorizado, secretos nuevos, HTTPS, servidor WSGI/ASGI y entrega de estáticos con collectstatic; nunca publicar MEDIA_ROOT directamente. La versión entregada es local y no constituye una certificación productiva del proceso.

Referencia de soporte del framework: https://www.djangoproject.com/download/ y https://docs.djangoproject.com/en/5.2/ .

## Etapas visuales del prototipo aprobado

El indicador compartido muestra las cuatro etapas del HTML v8: Identificación; Análisis de causa raíz; Solución inmediata y acciones correctivas; Evaluación de eficacia y cierre. Los estados y comprobaciones internos se conservan, sin añadir pasos al indicador.
